This pack contains 16 road tiles


image size of tiles
------------------------
128x94 pixels


view:
------------------------
Isometric view


tiles info
------------------------
With these tiles you can create almost every road combination.
this pack fits perfectly with my previous isometric pack released on opengameart.
http://opengameart.org/content/isometric-vehicles

For any questions or suggestions please feel free to conatct me on twitter or on my website
