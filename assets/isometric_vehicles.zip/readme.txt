This pack contains 8 spritesheets with all the cars in 1 color


Color:
-----------------------
red
light grey
green
mid blue
black
white
yellow
orange


resolution per vehicle
------------------------
32x32 pixels


view:
------------------------
Isometric view


Spritesheet info
------------------------
every line in the spritesheet has a car with 8 frames for its rotation.
The first frame of every car is facing south or pointing to the bottom left. every following frame is a rotation 45 degrees clockwise.

line 1: Basic sedan car 
line 2: Sport coupe
line 3: Hothatch car
line 4: Small delivery car
line 5: Station wagon
line 6: Minibus
line 7: Delivery van
line 8: Pickup truck

